import { Award, Briefcase, GraduationCap, Heart } from 'lucide-react';

const About = () => {
  const highlights = [
    {
      icon: Briefcase,
      title: '5+ Years',
      description: 'Professional Experience',
    },
    {
      icon: Award,
      title: '50+ Projects',
      description: 'Successfully Delivered',
    },
    {
      icon: GraduationCap,
      title: 'Continuous',
      description: 'Learning & Growth',
    },
    {
      icon: Heart,
      title: 'Passionate',
      description: 'About Technology',
    },
  ];

  return (
    <section id="about" className="py-20 bg-white dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4">
            About Me
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
            Passionate developer with a track record of delivering innovative solutions
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
          <div className="relative">
            <div className="aspect-square rounded-2xl overflow-hidden shadow-2xl">
              <div className="w-full h-full bg-gradient-to-br from-blue-100 to-indigo-100 dark:from-gray-800 dark:to-gray-700 flex items-center justify-center">
                <div className="text-center p-8">
                  <p className="text-gray-600 dark:text-gray-400 text-lg">
                    Professional Photo
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <h3 className="text-3xl font-bold text-gray-900 dark:text-white">
              My Journey
            </h3>
            <div className="space-y-4 text-gray-700 dark:text-gray-300 leading-relaxed">
              <p>
                I'm a full-stack developer passionate about creating exceptional digital experiences.
                My journey in software development began with a curiosity about how things work,
                which quickly evolved into a deep commitment to crafting elegant, user-centered solutions.
              </p>
              <p>
                With expertise spanning modern web technologies, I specialize in building scalable
                applications that marry beautiful design with robust functionality. I believe in writing
                clean, maintainable code and staying current with industry best practices.
              </p>
              <p>
                Beyond coding, I'm committed to continuous learning and contributing to the developer
                community. I enjoy tackling complex challenges and collaborating with teams to bring
                innovative ideas to life.
              </p>
            </div>

            <div className="pt-4">
              <a
                href="/resume.pdf"
                download
                className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-all shadow-lg hover:shadow-xl"
              >
                Download Resume
              </a>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {highlights.map((item, index) => {
            const Icon = item.icon;
            return (
              <div
                key={index}
                className="text-center p-6 bg-gray-50 dark:bg-gray-800 rounded-xl hover:shadow-lg transition-all transform hover:scale-105"
              >
                <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 dark:bg-blue-900/30 rounded-full mb-4">
                  <Icon className="text-blue-600 dark:text-blue-400" size={28} />
                </div>
                <h4 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                  {item.title}
                </h4>
                <p className="text-gray-600 dark:text-gray-400 text-sm">
                  {item.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default About;
